#!/bin/bash

AWS_REGION="us-east-1"
IN_BUCKET="csv-to-json-in-bucket-$(date +%s)"
OUT_BUCKET="csv-to-json-out-bucket-$(date +%s)"
LAMBDA_NAME="CsvToJsonLambda"

echo "### S3-Buckets erstellen ###"
aws s3api create-bucket --bucket $IN_BUCKET --region $AWS_REGION --create-bucket-configuration LocationConstraint=$AWS_REGION
aws s3api create-bucket --bucket $OUT_BUCKET --region $AWS_REGION --create-bucket-configuration LocationConstraint=$AWS_REGION

echo "### IAM-Rolle erstellen ###"
ROLE_NAME="LambdaExecutionRole"
ROLE_ARN=$(aws iam create-role --role-name $ROLE_NAME --assume-role-policy-document '{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": { "Service": "lambda.amazonaws.com" },
            "Action": "sts:AssumeRole"
        }
    ]
}' --query "Role.Arn" --output text)

aws iam put-role-policy --role-name $ROLE_NAME --policy-name LambdaS3Policy --policy-document "{
    \"Version\": \"2012-10-17\",
    \"Statement\": [
        { \"Effect\": \"Allow\", \"Action\": [\"s3:GetObject\", \"s3:PutObject\"], \"Resource\": [\"arn:aws:s3:::$IN_BUCKET/*\", \"arn:aws:s3:::$OUT_BUCKET/*\"] },
        { \"Effect\": \"Allow\", \"Action\": [\"logs:CreateLogGroup\", \"logs:CreateLogStream\", \"logs:PutLogEvents\"], \"Resource\": \"arn:aws:logs:$AWS_REGION:*:*\" }
    ]
}"

echo "### Warten, bis IAM-Rolle bereit ist ###"
sleep 10

echo "### Lambda-Funktion deployen ###"
dotnet publish -c Release -o ./publish
cd publish
zip -r ../CsvToJsonLambda.zip .
cd ..
aws lambda create-function --function-name $LAMBDA_NAME \
    --runtime dotnet6 \
    --role $ROLE_ARN \
    --handler CsvToJsonLambda::CsvToJsonLambda.Function::FunctionHandler \
    --timeout 30 \
    --memory-size 256 \
    --zip-file fileb://CsvToJsonLambda.zip \
    --environment Variables="{DEST_BUCKET=$OUT_BUCKET}"

echo "### S3-Trigger hinzufügen ###"
aws lambda add-permission --function-name $LAMBDA_NAME --statement-id AllowS3Invoke --action "lambda:InvokeFunction" --principal s3.amazonaws.com --source-arn "arn:aws:s3:::$IN_BUCKET"
aws s3api put-bucket-notification-configuration --bucket $IN_BUCKET --notification-configuration "{
    \"LambdaFunctionConfigurations\": [
        { \"LambdaFunctionArn\": \"$(aws lambda get-function --function-name $LAMBDA_NAME --query 'Configuration.FunctionArn' --output text)\", \"Events\": [\"s3:ObjectCreated:*\"] }
    ]
}"

echo "### Setup abgeschlossen ###"
echo "Input-Bucket: $IN_BUCKET"
echo "Output-Bucket: $OUT_BUCKET"
